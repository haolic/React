import React from 'react';
import {IndexLink,Link} from 'react-router';
class App extends React.Component{
	render(){
		return <div>
           <IndexLink to='/'>根路由</IndexLink><br/>
           <Link to='/page1' activeClassName='red'>page1组件</Link><br/>
           <Link to='/page2' activeClassName='green'>page2组件</Link>
            {/*加载子路由对应的组件*/}
            {this.props.children}
		</div>
	}
	componentDidMount() {
		console.log(this.props.children);
	}
}

export default App;