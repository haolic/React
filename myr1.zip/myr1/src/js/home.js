import React from 'react';
class Home extends React.Component{
	render(){
		return <div>
           欢迎使用react-router!
		</div>
	}
}
export default Home;