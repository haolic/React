import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,browserHistory,IndexRoute} from 'react-router';
import App from './app';
import Page1 from './page1';
import Page2 from './page2';
import Home from './home';
import style from './../css/style.css';

ReactDOM.render(
    <Router history={browserHistory}>
       <Route path='/' component={App} >
          <IndexRoute component={Home} />
          <Route path='/page1' component={Page1} />
          <Route path='/page2' component={Page2}  />
       </Route>
    </Router>,document.getElementById("div1")
	);
