import React from 'react';

class Page1 extends React.Component{
	render(){
		return <div>
           这是组件Page1

		</div>
	}
}
export default Page1;