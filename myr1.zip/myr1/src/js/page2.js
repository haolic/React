import React from 'react';
class Page2 extends React.Component{
	render(){
		return <div>
           这是组件Page2
		</div>
	}
}
export default Page2;