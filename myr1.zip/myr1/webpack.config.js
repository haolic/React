module.exports={
	entry:"./src/js/main.js",
	output:{
		path:__dirname+'/dist',
		filename:'bundle.js'
	},
	module:{
		loaders:[
        {
			test:/\.less$/,
			loader:'style-loader!css-loader!less-loader'
		 },
		{
			test:/\.css$/,loader:'style-loader!css-loader'
		},{
            test: /\.js?$/,//表示要编译的文件的类型，这里要编译的是js文件
            loader: 'babel-loader',//装载的哪些模块
            exclude: /node_modules/,//标识不编译node_modules文件夹下面的内容
            query: {//具体的编译的类型，
                compact: false,//表示不压缩
                presets: ['es2015', 'react']//我们需要编译的是es6和react
            }
        }
      ]
	}

}